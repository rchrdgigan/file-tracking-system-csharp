-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2022 at 06:30 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fts_dbs`
--

-- --------------------------------------------------------

--
-- Table structure for table `calamity_damage_tb`
--

CREATE TABLE `calamity_damage_tb` (
  `id` int(11) NOT NULL,
  `rsbsa_id` int(11) NOT NULL,
  `budget_from` varchar(60) NOT NULL,
  `date_from` varchar(10) NOT NULL,
  `type_calamity` varchar(20) NOT NULL,
  `amount_paid` varchar(20) NOT NULL,
  `ctc_no` varchar(20) NOT NULL,
  `ctc_date_issued` varchar(20) NOT NULL,
  `ctc_place_issued` varchar(60) NOT NULL,
  `created_at` varchar(10) NOT NULL,
  `updated_at` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'Normal'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `farmers_files_tb`
--

CREATE TABLE `farmers_files_tb` (
  `id` int(11) NOT NULL,
  `file_name` varchar(60) NOT NULL,
  `fname_extension` varchar(60) NOT NULL,
  `category` varchar(60) NOT NULL,
  `created_at` varchar(10) NOT NULL,
  `updated_at` varchar(10) NOT NULL,
  `status` varchar(10) DEFAULT 'Normal'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `fisheries_files_tb`
--

CREATE TABLE `fisheries_files_tb` (
  `id` int(11) NOT NULL,
  `file_name` varchar(60) NOT NULL,
  `fname_extension` varchar(60) NOT NULL,
  `category` varchar(60) NOT NULL,
  `created_at` varchar(10) NOT NULL,
  `updated_at` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'Normal'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `history_log_tb`
--

CREATE TABLE `history_log_tb` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `activity` varchar(200) NOT NULL,
  `date` varchar(10) NOT NULL,
  `time` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `rsbsa_tb`
--

CREATE TABLE `rsbsa_tb` (
  `id` int(11) NOT NULL,
  `surname` varchar(20) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `mname` varchar(20) NOT NULL,
  `extension` varchar(10) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `purok` varchar(20) NOT NULL,
  `street` varchar(20) NOT NULL,
  `brgy` varchar(20) NOT NULL,
  `municipality` varchar(20) NOT NULL,
  `province` varchar(20) NOT NULL,
  `region` varchar(20) NOT NULL,
  `mobile_no` varchar(20) NOT NULL,
  `landline_no` varchar(20) NOT NULL,
  `birthdate` varchar(20) NOT NULL,
  `birth_place` varchar(30) NOT NULL,
  `religion` varchar(20) NOT NULL,
  `civil_stat` varchar(20) NOT NULL,
  `spouse_name` varchar(60) NOT NULL,
  `mother_maiden` varchar(60) NOT NULL,
  `household_head` varchar(60) NOT NULL,
  `hh_relationship` varchar(20) NOT NULL,
  `no_living_mem` varchar(5) NOT NULL,
  `num_male` varchar(5) NOT NULL,
  `num_female` varchar(5) NOT NULL,
  `high_formal_educ` varchar(20) NOT NULL,
  `pdw` tinyint(1) NOT NULL,
  `four_ps` tinyint(1) NOT NULL,
  `mem_indigenous_group` varchar(60) NOT NULL,
  `govID_type` varchar(20) NOT NULL,
  `ID_no` varchar(20) NOT NULL,
  `mem_farmer_association` varchar(60) NOT NULL,
  `person_case_emergency` varchar(60) NOT NULL,
  `contact_num` varchar(15) NOT NULL,
  `livelihood` varchar(20) NOT NULL,
  `rice` tinyint(1) NOT NULL,
  `corn` tinyint(1) NOT NULL,
  `other_crops` varchar(30) NOT NULL,
  `other_livestock` varchar(30) NOT NULL,
  `other_poultry` varchar(30) NOT NULL,
  `land_preparation` tinyint(1) NOT NULL,
  `planting` tinyint(1) NOT NULL,
  `cultivation` tinyint(1) NOT NULL,
  `harvesting` tinyint(1) NOT NULL,
  `others_farm` varchar(30) NOT NULL,
  `fish_capture` tinyint(1) NOT NULL,
  `aquaculture` tinyint(1) NOT NULL,
  `gleaning` tinyint(1) NOT NULL,
  `fish_processing` tinyint(1) NOT NULL,
  `fish_vending` tinyint(1) NOT NULL,
  `others_fish` varchar(30) NOT NULL,
  `part_farm_hh` tinyint(1) NOT NULL,
  `att_form_afrc` tinyint(1) NOT NULL,
  `att_nonform_afrc` tinyint(1) NOT NULL,
  `participated_aaap` tinyint(1) NOT NULL,
  `others_agri_youth` varchar(30) NOT NULL,
  `income_farming` varchar(15) NOT NULL,
  `income_nonfarming` varchar(15) NOT NULL,
  `created_at` varchar(10) NOT NULL,
  `updated_at` varchar(10) NOT NULL,
  `status` varchar(10) DEFAULT 'Normal'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users_tb`
--

CREATE TABLE `users_tb` (
  `id` int(11) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `email` varchar(60) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `role` varchar(20) NOT NULL,
  `created_at` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'Normal'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users_tb`
--

INSERT INTO `users_tb` (`id`, `fname`, `lname`, `email`, `contact`, `username`, `password`, `role`, `created_at`, `status`) VALUES
(1, 'Admin Name', 'Admin Lastname', 'admin@example.com', '09531231414', 'admin', 'admin123', 'Admin', '2022-03-10', 'Normal'),
(3, 'Assistant Name', 'Assistant LastName', 'assitant@example.com', '093123123312', 'assistant', 'assistant123', 'Staff', '2022-03-25', 'Normal');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `calamity_damage_tb`
--
ALTER TABLE `calamity_damage_tb`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rsbsa_id` (`rsbsa_id`);

--
-- Indexes for table `farmers_files_tb`
--
ALTER TABLE `farmers_files_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fisheries_files_tb`
--
ALTER TABLE `fisheries_files_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history_log_tb`
--
ALTER TABLE `history_log_tb`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `rsbsa_tb`
--
ALTER TABLE `rsbsa_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_tb`
--
ALTER TABLE `users_tb`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `calamity_damage_tb`
--
ALTER TABLE `calamity_damage_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `farmers_files_tb`
--
ALTER TABLE `farmers_files_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `fisheries_files_tb`
--
ALTER TABLE `fisheries_files_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `history_log_tb`
--
ALTER TABLE `history_log_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=348;

--
-- AUTO_INCREMENT for table `rsbsa_tb`
--
ALTER TABLE `rsbsa_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users_tb`
--
ALTER TABLE `users_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `calamity_damage_tb`
--
ALTER TABLE `calamity_damage_tb`
  ADD CONSTRAINT `rsbsa_id` FOREIGN KEY (`rsbsa_id`) REFERENCES `rsbsa_tb` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `history_log_tb`
--
ALTER TABLE `history_log_tb`
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `users_tb` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
